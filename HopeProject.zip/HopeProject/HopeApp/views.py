from django.shortcuts import render
from django.views.generic import TemplateView

# Create your views here.
def home(request):
    return render(request,'app/index.html')

def Renewablesharemap(request):
    return render(request,'app/REusesharemap.html')

def Renewablesharegraph(request):
    return render(request,'app/REusessharegraph.html')